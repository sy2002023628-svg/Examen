# Niñas, niños y adolescentes atendidos por Educadores de Calle (MIMP)

Proyecto de datos de punta a punta: infraestructura como código (Terraform), base de datos PostgreSQL en AWS, carga automática con Liquibase, reporte en Power BI y publicación automatizada con GitHub Actions.

## 1. Detalle del dataset

| Campo | Detalle |
|---|---|
| Nombre | Números de niñas, niños y adolescentes atendidas en situación de calle, según sexo, grupo de edad |
| Fuente | [Datos Abiertos - Perú](https://www.datosabiertos.gob.pe/dataset/n%C3%BAmero-de-ni%C3%B1as-ni%C3%B1os-y-adolescentes-en-situaci%C3%B3n-de-calle-atendidos-mimp) |
| Entidad | Ministerio de la Mujer y Poblaciones Vulnerables (MIMP) |
| Servicio | Educadores de calle (línea: Protección integral) |
| Programas | Programa Nacional Yachay e INABIF (Programa Integral Nacional para el Bienestar Familiar) |
| Periodo | 2013 - 2025 |
| Archivo original | `1_2_1_BdD_Educadores_11.csv` (952 filas, 28 columnas) |
| Archivo usado | `data/educadores_calle_limpio.csv` |

**Limpieza aplicada:** conversión a UTF-8 y separador coma, nombres de columna en formato corto, fechas en formato `AAAA-MM-DD`, ubigeo de 6 dígitos, nombres de departamento sin tildes ni espacios sobrantes (por ejemplo `ÁNCASH` y `ANCASH` quedan como `ANCASH`). Los valores vacíos se cargan como `NULL`.

Cada fila representa la población atendida en un distrito, en un año de reporte.

## 2. Diccionario de datos

Tabla: `educadores_calle`

| Columna | Tipo | Descripción |
|---|---|---|
| id | SERIAL (PK) | Identificador autogenerado |
| anio_reporte | INT | Año del reporte de información |
| periodo_informacion | VARCHAR(20) | Periodo de la información remitida (ENE - DIC, ENE - SET) |
| fecha_reporte | DATE | Fecha en que se reportó la información |
| codigo_entidad | VARCHAR(10) | Código de la entidad (ENT002, ENT004) |
| nombre_programa | VARCHAR(120) | Nombre del programa que brinda el servicio |
| codigo_linea | VARCHAR(10) | Código de la línea de intervención |
| nombre_linea | VARCHAR(80) | Nombre de la línea de intervención |
| codigo_servicio | VARCHAR(10) | Código del servicio |
| nombre_servicio | VARCHAR(80) | Nombre del servicio (Educadores de calle) |
| ubigeo | CHAR(6) | Código de ubicación geográfica según INEI (nulo en algunos registros) |
| departamento | VARCHAR(50) | Departamento del centro de atención |
| provincia | VARCHAR(60) | Provincia del centro de atención |
| distrito | VARCHAR(80) | Distrito del centro de atención |
| pob_total | INT | Población atendida total |
| pob_hombres | INT | Población atendida: hombres |
| pob_mujeres | INT | Población atendida: mujeres |
| pob_0_5_total | INT | Población de 0 a 5 años: total |
| pob_0_5_hombres | INT | Población de 0 a 5 años: hombres |
| pob_0_5_mujeres | INT | Población de 0 a 5 años: mujeres |
| pob_6_11_total | INT | Población de 6 a 11 años: total |
| pob_6_11_hombres | INT | Población de 6 a 11 años: hombres |
| pob_6_11_mujeres | INT | Población de 6 a 11 años: mujeres |
| pob_12_17_total | INT | Población de 12 a 17 años: total |
| pob_12_17_hombres | INT | Población de 12 a 17 años: hombres |
| pob_12_17_mujeres | INT | Población de 12 a 17 años: mujeres |
| pob_18_mas_total | INT | Población de 18 años a más: total |
| pob_18_mas_hombres | INT | Población de 18 años a más: hombres |
| pob_18_mas_mujeres | INT | Población de 18 años a más: mujeres |

## 3. Diagrama entidad-relación

El dataset se modela en una sola tabla de hechos. La ubicación geográfica y el programa se muestran como atributos descriptivos dentro de la misma tabla.

```mermaid
erDiagram
    EDUCADORES_CALLE {
        int id PK
        int anio_reporte
        varchar periodo_informacion
        date fecha_reporte
        varchar codigo_entidad
        varchar nombre_programa
        varchar codigo_linea
        varchar nombre_linea
        varchar codigo_servicio
        varchar nombre_servicio
        char ubigeo
        varchar departamento
        varchar provincia
        varchar distrito
        int pob_total
        int pob_hombres
        int pob_mujeres
        int pob_0_5_total
        int pob_6_11_total
        int pob_12_17_total
        int pob_18_mas_total
    }
```

*(Por brevedad, el diagrama muestra solo las columnas principales; el detalle completo está en el diccionario de datos.)*

## 4. Diagrama de despliegue e infraestructura

```mermaid
flowchart LR
    DEV[Desarrollador] -->|git push| GH[Repositorio GitHub]

    subgraph GA[GitHub Actions]
        INFRA[infra.yml<br/>Terraform]
        SETUP[setup.yml<br/>Liquibase]
        DEPLOY[deploy.yml<br/>PowerShell]
    end

    GH --> INFRA
    GH --> SETUP
    GH --> DEPLOY

    subgraph AWS[AWS]
        RDS[(RDS PostgreSQL<br/>db.t3.micro)]
    end

    INFRA -->|crea servidor y security group| RDS
    SETUP -->|crea tabla y carga CSV| RDS

    PBID[Power BI Desktop<br/>reporte .pbix] -->|git push| GH
    DEPLOY -->|publica .pbix| PBIS[Power BI Service]
    RDS -->|origen de datos| PBID
    PBIS --> USR[Usuarios con acceso al reporte]
```

| Componente | Función |
|---|---|
| `infra.yml` | Crea el servidor PostgreSQL (RDS) en AWS con Terraform |
| `setup.yml` | Ejecuta Liquibase: crea la tabla y carga los datos |
| `deploy.yml` | Publica el reporte `.pbix` en Power BI Service |

## 5. Estructura del repositorio

```
├── README.md
├── data/educadores_calle_limpio.csv
├── sql/
│   ├── 01_crear_tablas.sql
│   └── 02_cargar_datos.sql
├── terraform/
│   ├── main.tf
│   ├── variables.tf
│   └── outputs.tf
├── liquibase/
│   ├── changelog.xml
│   └── data/educadores_calle.csv
├── powerbi/reporte_ninos_calle.pbix
└── .github/workflows/
    ├── infra.yml
    ├── setup.yml
    └── deploy.yml
```

## 6. Cómo ejecutar

1. Configurar los secretos del repositorio (Settings > Secrets and variables > Actions): `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `DB_PASSWORD`, `PBI_TENANT_ID`, `PBI_CLIENT_ID`, `PBI_CLIENT_SECRET`, `PBI_WORKSPACE`.
2. Ejecutar el workflow **infra** (crea la base de datos en AWS).
3. Ejecutar el workflow **setup** (crea la tabla y carga los datos).
4. Conectar Power BI Desktop a la base de datos, construir el reporte y guardarlo en `powerbi/`.
5. Ejecutar el workflow **deploy** (publica el reporte).

## 7. Reporte

- **Panorama general:** población atendida por año y por departamento.
- **Sexo y edad:** distribución por sexo y por grupo de edad.
- **Detalle:** tabla por departamento, provincia y distrito con filtros.

URL del reporte publicado: _(completar)_
